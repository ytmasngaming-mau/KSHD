package com.kshd.enhancer.ui

import android.graphics.ImageDecoder
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.kshd.enhancer.core.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

@Composable
fun PhotoScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var uri by remember { mutableStateOf<Uri?>(null) }
    var dims by remember { mutableStateOf<Pair<Int, Int>?>(null) }
    var target by remember { mutableStateOf(ResTarget.K4) }
    var fmt by remember { mutableStateOf(OutFormat.JPG) }
    var quality by remember { mutableFloatStateOf(0.92f) }
    var modelInfo by remember { mutableStateOf(ModelStore.info(ctx)) }
    var range255 by remember { mutableStateOf(ModelStore.range255(ctx)) }
    var busy by remember { mutableStateOf(false) }
    var stage by remember { mutableStateOf("") }
    var done by remember { mutableIntStateOf(0) }
    var total by remember { mutableIntStateOf(0) }
    var error by remember { mutableStateOf("") }
    var info by remember { mutableStateOf("") }
    var result by remember { mutableStateOf<PhotoResult?>(null) }
    var before by remember { mutableStateOf<ImageBitmap?>(null) }
    var after by remember { mutableStateOf<ImageBitmap?>(null) }
    var job by remember { mutableStateOf<Job?>(null) }

    val pickImage = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { u ->
        if (u != null) {
            uri = u; result = null; after = null; info = ""; error = ""
            dims = readBounds(ctx, u)
            if (dims == null) error = "File gambar rusak atau tidak didukung."
            else before = runCatching { decodePreview(ImageDecoder.createSource(ctx.contentResolver, u)).asImageBitmap() }.getOrNull()
        }
    }
    val pickModel = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) scope.launch {
            error = ""
            try {
                modelInfo = withContext(Dispatchers.IO) { ModelStore.install(ctx, u) }
            } catch (e: Throwable) {
                error = "Model ditolak: ${e.message}"
            }
        }
    }

    val scale = remember(modelInfo) { modelInfo?.substringAfter("×")?.toIntOrNull() ?: 4 }
    val plan = remember(dims, target, scale) { dims?.let { PhotoPipeline.plan(it.first, it.second, target, scale) } }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)) {

        Text("Model AI: ${modelInfo ?: "belum terpasang — fitur AI belum tersedia"}")
        OutlinedButton(onClick = { pickModel.launch(arrayOf("*/*")) }, enabled = !busy) { Text("Pasang model .tflite") }
        ChipRow("Rentang input model", listOf(false, true), range255, { if (it) "0–255" else "0–1" }) {
            range255 = it; ModelStore.setRange255(ctx, it)
        }
        Note("Cara pasang & model yang kompatibel: lihat README. Gambar diproses di perangkat, tidak dikirim ke server.")

        Button(onClick = { pickImage.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
            enabled = !busy) { Text("Pilih Foto") }
        dims?.let { Note("Sumber: ${it.first}×${it.second}") }

        ChipRow("Target resolusi (sisi panjang)",
            listOf(ResTarget.ORIGINAL, ResTarget.K2, ResTarget.K4, ResTarget.K8, ResTarget.AUTO), target, { it.label }) { target = it }
        ChipRow("Format", OutFormat.values().toList(), fmt, { it.label }) { fmt = it }
        if (fmt == OutFormat.JPG) {
            Text("Kualitas JPG: ${(quality * 100).roundToInt()}")
            Slider(value = quality, onValueChange = { quality = it }, valueRange = 0.6f..1f)
        }
        plan?.let {
            if (it.ok) {
                val px = dims!!.let { d -> val (a, b) = scaledDims(d.first, d.second, it.longSide); a.toLong() * b }
                val est = if (fmt == OutFormat.JPG) px / 2 else px * 5 / 2
                Note("Hasil ±${it.longSide}px sisi panjang, perkiraan kasar ukuran file ${mb(est)} MB. ${it.message}")
            } else Note(it.message, error = true)
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                enabled = !busy && uri != null && modelInfo != null && plan?.ok == true,
                onClick = {
                    busy = true; error = ""; result = null; after = null; info = ""; done = 0; total = 0
                    job = scope.launch {
                        try {
                            val r = withContext(Dispatchers.Default) {
                                PhotoPipeline.run(ctx, uri!!, target, fmt, (quality * 100).roundToInt(),
                                    { stage = it }, { d, t -> done = d; total = t })
                            }
                            result = r
                            after = decodePreview(ImageDecoder.createSource(r.file)).asImageBitmap()
                            stage = "Selesai: ${r.width}×${r.height} (terverifikasi)"
                        } catch (e: CancellationException) {
                            stage = "Dibatalkan"
                        } catch (e: OutOfMemoryError) {
                            error = "Memori habis. Pilih target lebih rendah."
                        } catch (e: Throwable) {
                            error = e.message ?: e.toString()
                        } finally { busy = false }
                    }
                }) { Text("Proses") }
            if (busy) OutlinedButton(onClick = { job?.cancel() }) { Text("Batal") }
        }

        if (busy || stage.isNotEmpty()) Note(stage)
        if (busy && total > 0) {
            LinearProgressIndicator(progress = { done.toFloat() / total }, modifier = Modifier.fillMaxWidth())
            Note("Tile $done / $total")
        } else if (busy) LinearProgressIndicator(Modifier.fillMaxWidth())
        Note(error, error = true)

        val b = before; val a = after
        if (b != null && a != null) CompareSlider(b, a)
        Note("Catatan: super-resolution AI memperkirakan detail; hasilnya tidak selalu sama dengan detail asli.")

        result?.let { r ->
            Button(onClick = {
                scope.launch {
                    try {
                        withContext(Dispatchers.IO) {
                            saveToGallery(ctx, r.file, r.fmt.mime, "KSHD_${System.currentTimeMillis()}.${r.fmt.ext}", false)
                        }
                        info = "Tersimpan di galeri: Pictures/KSHD"
                    } catch (e: Throwable) { error = "Gagal menyimpan: ${e.message}" }
                }
            }) { Text("Simpan ke Galeri") }
            Note(info)
        }
    }
}
