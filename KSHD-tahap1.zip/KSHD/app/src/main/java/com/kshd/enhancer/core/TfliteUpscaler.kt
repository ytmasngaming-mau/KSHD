package com.kshd.enhancer.core

import android.graphics.Bitmap
import org.tensorflow.lite.DataType
import org.tensorflow.lite.Interpreter
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.coroutines.cancellation.CancellationException
import kotlin.math.max
import kotlin.math.min

/**
 * Super-resolution tile-based untuk model TFLite float32 NHWC dengan input tetap [1,H,W,3]
 * dan output [1,H*s,W*s,3] (mis. ESRGAN / Real-ESRGAN hasil konversi).
 * Rentang nilai model: 0..1 (range255=false) atau 0..255 (range255=true).
 */
class TfliteUpscaler(modelFile: File, private val range255: Boolean) : AutoCloseable {
    private val interpreter: Interpreter
    val tileW: Int
    val tileH: Int
    val scale: Int

    init {
        val opts = Interpreter.Options().setNumThreads(Runtime.getRuntime().availableProcessors().coerceIn(2, 6))
        interpreter = Interpreter(modelFile, opts)
        try {
            val inT = interpreter.getInputTensor(0)
            val outT = interpreter.getOutputTensor(0)
            require(inT.dataType() == DataType.FLOAT32 && outT.dataType() == DataType.FLOAT32) {
                "Model harus float32 (model terkuantisasi belum didukung)."
            }
            val i = inT.shape()
            val o = outT.shape()
            require(i.size == 4 && o.size == 4 && i[3] == 3 && o[3] == 3 && i[1] > 0 && i[2] > 0) {
                "Model harus berinput tetap [1,H,W,3]. Bentuk input: ${i.contentToString()}"
            }
            tileH = i[1]; tileW = i[2]
            require(o[1] % tileH == 0 && o[2] % tileW == 0 && o[1] / tileH == o[2] / tileW && o[1] / tileH >= 2) {
                "Output model bukan kelipatan input. Input ${i.contentToString()}, output ${o.contentToString()}"
            }
            scale = o[1] / tileH
            require(tileW > 2 * PAD + 4 && tileH > 2 * PAD + 4) { "Ukuran tile model terlalu kecil." }
        } catch (e: Throwable) {
            interpreter.close(); throw e
        }
    }

    fun upscale(src: Bitmap, onProgress: (Int, Int) -> Unit, cancelled: () -> Boolean): Bitmap {
        val w = src.width
        val h = src.height
        val coreW = tileW - 2 * PAD
        val coreH = tileH - 2 * PAD
        val outW = tileW * scale
        val out = Bitmap.createBitmap(w * scale, h * scale, Bitmap.Config.ARGB_8888)
        val cols = (w + coreW - 1) / coreW
        val rows = (h + coreH - 1) / coreH
        val total = cols * rows
        val inScale = if (range255) 1f else 1f / 255f
        val outMul = if (range255) 1f else 255f
        val inBuf = ByteBuffer.allocateDirect(tileW * tileH * 3 * 4).order(ByteOrder.nativeOrder())
        val outBuf = ByteBuffer.allocateDirect(outW * tileH * scale * 3 * 4).order(ByteOrder.nativeOrder())
        val region = IntArray(tileW * tileH)
        val outPix = IntArray(coreW * scale * coreH * scale)
        var done = 0
        try {
            for (ty in 0 until rows) for (tx in 0 until cols) {
                if (cancelled()) throw CancellationException("Dibatalkan")
                val cx = tx * coreW
                val cy = ty * coreH
                val cw = min(coreW, w - cx)
                val ch = min(coreH, h - cy)
                val x0 = max(0, cx - PAD); val y0 = max(0, cy - PAD)
                val x1 = min(w, cx + coreW + PAD); val y1 = min(h, cy + coreH + PAD)
                val rw = x1 - x0; val rh = y1 - y0
                src.getPixels(region, 0, rw, x0, y0, rw, rh)
                inBuf.rewind()
                for (j in 0 until tileH) {
                    val sy = (cy - PAD + j).coerceIn(0, h - 1) - y0
                    for (i in 0 until tileW) {
                        val sx = (cx - PAD + i).coerceIn(0, w - 1) - x0
                        val p = region[sy * rw + sx]
                        inBuf.putFloat(((p shr 16) and 255) * inScale)
                        inBuf.putFloat(((p shr 8) and 255) * inScale)
                        inBuf.putFloat((p and 255) * inScale)
                    }
                }
                inBuf.rewind(); outBuf.rewind()
                interpreter.run(inBuf, outBuf)
                outBuf.rewind()
                val fb = outBuf.asFloatBuffer()
                val ow = cw * scale
                val oh = ch * scale
                val ox0 = PAD * scale
                val oy0 = PAD * scale
                for (j in 0 until oh) {
                    for (i in 0 until ow) {
                        val idx = ((oy0 + j) * outW + ox0 + i) * 3
                        val r = (fb.get(idx) * outMul).toInt().coerceIn(0, 255)
                        val g = (fb.get(idx + 1) * outMul).toInt().coerceIn(0, 255)
                        val b = (fb.get(idx + 2) * outMul).toInt().coerceIn(0, 255)
                        outPix[j * ow + i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
                    }
                }
                out.setPixels(outPix, 0, ow, cx * scale, cy * scale, ow, oh)
                done++
                onProgress(done, total)
            }
        } catch (e: Throwable) {
            out.recycle(); throw e
        }
        return out
    }

    override fun close() = interpreter.close()

    companion object {
        const val PAD = 8
    }
}
