@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package com.kshd.enhancer.core

import android.content.Context
import android.media.MediaCodecList
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlin.math.abs
import kotlin.math.max

enum class Codec(val label: String, val mime: String, val bppFactor: Double) {
    H264("H.264", MimeTypes.VIDEO_H264, 1.0),
    HEVC("HEVC (H.265)", MimeTypes.VIDEO_H265, 0.7)
}

enum class VQuality(val label: String, val bpp: Double) {
    LOW("Rendah", 0.05), MED("Sedang", 0.08), HIGH("Tinggi", 0.12)
}

data class VideoInfo(
    val dispW: Int, val dispH: Int, val durationMs: Long, val fps: Double,
    val hasAudio: Boolean, val srcBitrate: Long
)

data class VideoPlan(
    val ok: Boolean, val message: String, val warning: String,
    val w: Int, val h: Int, val bitrate: Long, val estBytes: Long
)

data class VideoResult(
    val file: File, val w: Int, val h: Int, val durationMs: Long,
    val hasAudio: Boolean, val codecNote: String
)

object VideoPipeline {

    fun probe(ctx: Context, uri: Uri): VideoInfo {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, uri)
            fun i(k: Int) = r.extractMetadata(k)?.toLongOrNull()
            val w = i(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toInt() ?: error("Bukan file video yang valid.")
            val h = i(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toInt() ?: error("Bukan file video yang valid.")
            val rot = i(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toInt() ?: 0
            val dur = i(MediaMetadataRetriever.METADATA_KEY_DURATION) ?: 0L
            val frames = i(MediaMetadataRetriever.METADATA_KEY_VIDEO_FRAME_COUNT) ?: 0L
            val fps = if (dur > 0 && frames > 0) frames * 1000.0 / dur else 30.0
            val audio = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_HAS_AUDIO) == "yes"
            val br = i(MediaMetadataRetriever.METADATA_KEY_BITRATE) ?: 0L
            val swap = rot == 90 || rot == 270
            return VideoInfo(if (swap) h else w, if (swap) w else h, dur, fps, audio, br)
        } finally {
            r.release()
        }
    }

    private fun even(x: Int) = max(2, x / 2 * 2)

    private fun encoderCaps(mime: String, w: Int, h: Int): android.media.MediaCodecInfo.VideoCapabilities? =
        MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.asSequence()
            .filter { it.isEncoder && it.supportedTypes.any { t -> t.equals(mime, true) } }
            .mapNotNull { runCatching { it.getCapabilitiesForType(mime).videoCapabilities }.getOrNull() }
            .firstOrNull { runCatching { it.isSizeSupported(w, h) }.getOrDefault(false) }

    fun hevcAvailable(): Boolean = MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos
        .any { it.isEncoder && it.supportedTypes.any { t -> t.equals(MimeTypes.VIDEO_H265, true) } }

    fun plan(ctx: Context, info: VideoInfo, target: ResTarget, codec: Codec, q: VQuality): VideoPlan {
        val srcLong = max(info.dispW, info.dispH)
        fun dims(t: Int) = scaledDims(info.dispW, info.dispH, t).let { Pair(even(it.first), even(it.second)) }
        val t: Int = when (target) {
            ResTarget.ORIGINAL -> srcLong
            ResTarget.AUTO -> {
                val cap = if (info.durationMs > 10 * 60_000) 1920 else 3840
                val c = listOf(1280, 1920, 2560, 3840).firstOrNull { it > srcLong && it <= cap }
                if (c != null && encoderCaps(codec.mime, dims(c).first, dims(c).second) != null) c else srcLong
            }
            else -> target.longSide
        }
        val (w, h) = dims(t)
        val caps = encoderCaps(codec.mime, w, h)
            ?: return VideoPlan(false,
                "Encoder ${codec.label} di perangkat ini tidak mendukung ${w}×${h}. Coba 4K atau codec lain.", "", w, h, 0, 0)
        var br = (w.toDouble() * h * info.fps * q.bpp * codec.bppFactor).toLong().coerceAtLeast(500_000)
        br = br.coerceIn(caps.bitrateRange.lower.toLong(), caps.bitrateRange.upper.toLong())
        val est = (br + (if (info.hasAudio) 128_000 else 0)) * info.durationMs / 8000
        val free = ctx.cacheDir.usableSpace
        if (free < est * 2 + 50L * 1024 * 1024)
            return VideoPlan(false,
                "Ruang penyimpanan kurang (butuh ±${mb(est * 2 + 50L * 1024 * 1024)} MB, tersedia ${mb(free)} MB).", "", w, h, br, est)
        val warn = if (t > srcLong)
            "Ini upscale resolusi biasa (bukan AI Video Super Resolution): detail baru tidak ditambahkan." else ""
        return VideoPlan(true, "", warn, w, h, br, est)
    }

    private fun videoMime(f: File): String? {
        val e = MediaExtractor()
        return try {
            e.setDataSource(f.absolutePath)
            (0 until e.trackCount).map { e.getTrackFormat(it).getString(MediaFormat.KEY_MIME) }
                .firstOrNull { it?.startsWith("video/") == true }
        } finally { e.release() }
    }

    /** progress: 0..100, atau -1 jika belum tersedia (tidak mengarang persentase). */
    suspend fun run(ctx: Context, uri: Uri, info: VideoInfo, plan: VideoPlan, codec: Codec,
                    onProgress: (Int) -> Unit): VideoResult {
        val out = File(ctx.cacheDir, "kshd_${System.currentTimeMillis()}.mp4")
        try {
            export(ctx, uri, info, plan, codec, out, onProgress)
            val v = probe(ctx, Uri.fromFile(out))
            val problems = buildList {
                if (abs(v.dispW - plan.w) > 2 || abs(v.dispH - plan.h) > 2) add("resolusi ${v.dispW}×${v.dispH} ≠ ${plan.w}×${plan.h}")
                if (abs(v.durationMs - info.durationMs) > max(1000L, info.durationMs / 50)) add("durasi ${v.durationMs}ms ≠ ${info.durationMs}ms")
                if (v.hasAudio != info.hasAudio) add("status audio berubah")
            }
            if (problems.isNotEmpty()) error("Verifikasi gagal: " + problems.joinToString("; "))
            val m = videoMime(out)
            val note = if (m != null && !m.equals(codec.mime, true)) "Encoder beralih otomatis ke $m." else ""
            return VideoResult(out, v.dispW, v.dispH, v.durationMs, v.hasAudio, note)
        } catch (e: Throwable) {
            out.delete(); throw e
        }
    }

    private suspend fun export(ctx: Context, uri: Uri, info: VideoInfo, plan: VideoPlan, codec: Codec,
                               out: File, onProgress: (Int) -> Unit) =
        suspendCancellableCoroutine<Unit> { cont ->
            val main = Handler(Looper.getMainLooper())
            var transformer: Transformer? = null
            var polling = true
            main.post {
                try {
                    val encoder = DefaultEncoderFactory.Builder(ctx)
                        .setRequestedVideoEncoderSettings(VideoEncoderSettings.Builder().setBitrate(plan.bitrate.toInt()).build())
                        .build()
                    val t = Transformer.Builder(ctx)
                        .setVideoMimeType(codec.mime)
                        .setEncoderFactory(encoder)
                        .addListener(object : Transformer.Listener {
                            override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                                polling = false
                                if (cont.isActive) cont.resume(Unit)
                            }
                            override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                                polling = false
                                if (cont.isActive) cont.resumeWithException(exportException)
                            }
                        }).build()
                    transformer = t
                    val vEffects = mutableListOf<Effect>()
                    if (plan.h != info.dispH) vEffects.add(Presentation.createForHeight(plan.h))
                    val item = EditedMediaItem.Builder(MediaItem.fromUri(uri))
                        .setEffects(Effects(listOf<AudioProcessor>(), vEffects))
                        .build()
                    t.start(item, out.absolutePath)
                    val holder = ProgressHolder()
                    val poll = object : Runnable {
                        override fun run() {
                            if (!polling) return
                            val s = t.getProgress(holder)
                            onProgress(if (s == Transformer.PROGRESS_STATE_AVAILABLE) holder.progress else -1)
                            main.postDelayed(this, 300)
                        }
                    }
                    main.post(poll)
                } catch (e: Throwable) {
                    if (cont.isActive) cont.resumeWithException(e)
                }
            }
            cont.invokeOnCancellation { main.post { polling = false; transformer?.cancel() } }
        }
}
