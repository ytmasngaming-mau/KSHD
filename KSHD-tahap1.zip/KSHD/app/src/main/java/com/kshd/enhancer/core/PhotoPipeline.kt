package com.kshd.enhancer.core

import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import kotlin.coroutines.coroutineContext
import kotlinx.coroutines.Job
import kotlin.math.max

object ModelStore {
    fun file(ctx: Context) = File(ctx.filesDir, "models/upscaler.tflite")
    private fun prefs(ctx: Context) = ctx.getSharedPreferences("model", Context.MODE_PRIVATE)
    fun info(ctx: Context): String? = if (file(ctx).exists()) prefs(ctx).getString("info", null) else null
    fun range255(ctx: Context) = prefs(ctx).getBoolean("range255", false)
    fun setRange255(ctx: Context, v: Boolean) = prefs(ctx).edit().putBoolean("range255", v).apply()

    /** Salin model dari picker, validasi dengan benar-benar memuatnya. Mengembalikan deskripsi. */
    fun install(ctx: Context, uri: Uri): String {
        val f = file(ctx)
        f.parentFile!!.mkdirs()
        val tmp = File(f.parentFile, "upscaler.tmp")
        ctx.contentResolver.openInputStream(uri)!!.use { i -> FileOutputStream(tmp).use { i.copyTo(it) } }
        try {
            val d = TfliteUpscaler(tmp, range255(ctx)).use { "Tile ${it.tileW}×${it.tileH}, skala ×${it.scale}" }
            tmp.copyTo(f, overwrite = true)
            prefs(ctx).edit().putString("info", d).apply()
            return d
        } finally {
            tmp.delete()
        }
    }
}

data class PhotoPlan(val ok: Boolean, val message: String, val longSide: Int, val aiScale: Int)

data class PhotoResult(val file: File, val width: Int, val height: Int, val note: String, val fmt: OutFormat)

object PhotoPipeline {
    private const val SLACK = 24L * 1024 * 1024

    private fun need(w: Int, h: Int, scale: Int, t: Int): Long {
        val f = t.toDouble() / max(w, h)
        val tw = (w * f).toLong(); val th = (h * f).toLong()
        val ai = w.toLong() * scale * h * scale * 4
        val fin = if (tw == w.toLong() * scale) 0L else tw * th * 4
        return w.toLong() * h * 4 + ai + fin + SLACK
    }

    fun plan(w: Int, h: Int, target: ResTarget, scale: Int): PhotoPlan {
        val srcLong = max(w, h)
        val avail = availableHeap()
        fun fits(t: Int) = need(w, h, scale, t) <= avail
        val t: Int = when (target) {
            ResTarget.ORIGINAL -> srcLong
            ResTarget.AUTO -> {
                val c = listOf(ResTarget.K8, ResTarget.K4, ResTarget.K2).map { it.longSide }
                    .filter { it > srcLong && it <= srcLong * scale && fits(it) }
                c.firstOrNull() ?: return PhotoPlan(false,
                    "Auto: tidak ada target 2K/4K/8K yang lebih besar dari sumber dan muat di memori perangkat.", 0, scale)
            }
            else -> target.longSide
        }
        if (target != ResTarget.ORIGINAL && t <= srcLong)
            return PhotoPlan(false, "Sumber (${srcLong}px) sudah ≥ target ${t}px. Pilih target lebih besar atau Original.", t, scale)
        if (!fits(t))
            return PhotoPlan(false,
                "Memori perangkat tidak cukup (butuh ±${mb(need(w, h, scale, t))} MB, tersedia ±${mb(avail)} MB). Pilih target lebih rendah.", t, scale)
        val note = if (t > srcLong * scale)
            "Model AI hanya ×$scale; sisa pembesaran memakai resize biasa (bukan AI)." else ""
        return PhotoPlan(true, note, t, scale)
    }

    suspend fun run(
        ctx: Context, uri: Uri, target: ResTarget, fmt: OutFormat, quality: Int,
        onStage: (String) -> Unit, onProgress: (Int, Int) -> Unit
    ): PhotoResult {
        val model = ModelStore.file(ctx)
        if (!model.exists()) error("Model AI belum terpasang. Pasang file .tflite terlebih dahulu.")
        val job = coroutineContext[Job]
        val cancelled = { job?.isActive == false }

        onStage("Memuat model…")
        TfliteUpscaler(model, ModelStore.range255(ctx)).use { up ->
            onStage("Membaca gambar…")
            val b = readBounds(ctx, uri) ?: error("File gambar rusak atau tidak didukung.")
            val pre = plan(b.first, b.second, target, up.scale)
            if (!pre.ok) error(pre.message)
            val src = decodeFull(ctx, uri)
            var ai: Bitmap? = null
            var fin: Bitmap? = null
            try {
                val sw = src.width; val sh = src.height
                val p = plan(sw, sh, target, up.scale)
                if (!p.ok) error(p.message)
                onStage("Super-resolution AI ×${up.scale}…")
                ai = up.upscale(src, onProgress, cancelled)
                src.recycle()
                val (tw, th) = scaledDims(sw, sh, p.longSide)
                onStage("Menyesuaikan ke ${tw}×${th}…")
                fin = if (ai.width == tw && ai.height == th) ai else Bitmap.createScaledBitmap(ai, tw, th, true)
                if (fin !== ai) { ai.recycle(); ai = null }
                if (cancelled()) throw kotlin.coroutines.cancellation.CancellationException("Dibatalkan")
                onStage("Menyimpan hasil…")
                val out = File(ctx.cacheDir, "kshd_${System.currentTimeMillis()}.${fmt.ext}")
                val ok = FileOutputStream(out).use {
                    fin.compress(if (fmt == OutFormat.JPG) Bitmap.CompressFormat.JPEG else Bitmap.CompressFormat.PNG, quality, it)
                }
                if (!ok) { out.delete(); error("Gagal menulis file hasil.") }
                onStage("Memverifikasi hasil…")
                val vb = readFileBounds(out)
                if (vb == null || vb.first != tw || vb.second != th) {
                    out.delete(); error("Verifikasi gagal: dimensi hasil ${vb} ≠ ${tw}×${th}.")
                }
                return PhotoResult(out, tw, th, p.message, fmt)
            } finally {
                if (!src.isRecycled) src.recycle()
                ai?.let { if (!it.isRecycled) it.recycle() }
                fin?.let { if (!it.isRecycled) it.recycle() }
            }
        }
    }
}
