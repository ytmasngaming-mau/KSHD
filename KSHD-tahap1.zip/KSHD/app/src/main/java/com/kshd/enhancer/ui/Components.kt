package com.kshd.enhancer.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

@Composable
fun <T> ChipRow(title: String, options: List<T>, selected: T, label: (T) -> String, onSelect: (T) -> Unit) {
    Column(Modifier.padding(vertical = 4.dp)) {
        Text(title, style = MaterialTheme.typography.labelLarge)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            options.forEach { o ->
                FilterChip(selected = o == selected, onClick = { onSelect(o) }, label = { Text(label(o)) })
            }
        }
    }
}

@Composable
fun Note(text: String, error: Boolean = false) {
    if (text.isBlank()) return
    Text(text, style = MaterialTheme.typography.bodySmall,
        color = if (error) Color(0xFFFF6B6B) else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.75f),
        modifier = Modifier.padding(vertical = 4.dp))
}

@Composable
fun CompareSlider(before: ImageBitmap, after: ImageBitmap, modifier: Modifier = Modifier) {
    var frac by remember { mutableFloatStateOf(0.5f) }
    BoxWithConstraints(modifier.fillMaxWidth()) {
        val w: Dp = maxWidth
        Box(Modifier
            .fillMaxWidth()
            .aspectRatio(after.width.toFloat() / after.height)
            .pointerInput(Unit) {
                detectHorizontalDragGestures { change, _ -> frac = (change.position.x / size.width).coerceIn(0f, 1f) }
            }) {
            Image(after, "Sesudah", Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
            Image(before, "Sebelum",
                Modifier.fillMaxSize().clip(object : Shape {
                    override fun createOutline(size: androidx.compose.ui.geometry.Size, layoutDirection: LayoutDirection, density: Density) =
                        Outline.Rectangle(Rect(0f, 0f, size.width * frac, size.height))
                }), contentScale = ContentScale.FillBounds)
            Box(Modifier.fillMaxHeight().width(2.dp).background(Color.White)
                .offset { IntOffset((w.toPx() * frac).roundToInt(), 0) })
            Text("Sebelum", Modifier.align(Alignment.TopStart).padding(6.dp).background(Color(0x99000000)).padding(4.dp),
                color = Color.White, style = MaterialTheme.typography.labelSmall)
            Text("Sesudah", Modifier.align(Alignment.TopEnd).padding(6.dp).background(Color(0x99000000)).padding(4.dp),
                color = Color.White, style = MaterialTheme.typography.labelSmall)
        }
    }
}
