package com.kshd.enhancer.core

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageDecoder
import android.net.Uri
import android.provider.MediaStore
import java.io.File
import kotlin.math.max
import kotlin.math.roundToInt

enum class ResTarget(val label: String, val longSide: Int) {
    ORIGINAL("Original", 0),
    P720("720p", 1280),
    P1080("1080p", 1920),
    K2("2K", 2560),
    K4("4K", 3840),
    K8("8K", 7680),
    AUTO("Auto", -1)
}

enum class OutFormat(val label: String, val mime: String, val ext: String) {
    JPG("JPG", "image/jpeg", "jpg"),
    PNG("PNG", "image/png", "png")
}

fun scaledDims(w: Int, h: Int, longSide: Int): Pair<Int, Int> {
    val f = longSide.toDouble() / max(w, h)
    return Pair(max(1, (w * f).roundToInt()), max(1, (h * f).roundToInt()))
}

fun availableHeap(): Long {
    val rt = Runtime.getRuntime()
    return rt.maxMemory() - (rt.totalMemory() - rt.freeMemory())
}

fun mb(bytes: Long) = bytes / (1024 * 1024)

fun readBounds(ctx: Context, uri: Uri): Pair<Int, Int>? =
    ctx.contentResolver.openInputStream(uri)?.use {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeStream(it, null, o)
        if (o.outWidth > 0 && o.outHeight > 0) Pair(o.outWidth, o.outHeight) else null
    }

fun readFileBounds(file: File): Pair<Int, Int>? {
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(file.absolutePath, o)
    return if (o.outWidth > 0) Pair(o.outWidth, o.outHeight) else null
}

/** Decode penuh, software bitmap (bisa getPixels), orientasi EXIF otomatis diterapkan ImageDecoder. */
fun decodeFull(ctx: Context, uri: Uri): Bitmap =
    ImageDecoder.decodeBitmap(ImageDecoder.createSource(ctx.contentResolver, uri)) { d, _, _ ->
        d.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
    }

fun decodePreview(source: ImageDecoder.Source, maxSide: Int = 1600): Bitmap =
    ImageDecoder.decodeBitmap(source) { d, info, _ ->
        d.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
        val l = max(info.size.width, info.size.height)
        if (l > maxSide) {
            val s = maxSide.toFloat() / l
            d.setTargetSize((info.size.width * s).toInt().coerceAtLeast(1), (info.size.height * s).toInt().coerceAtLeast(1))
        }
    }

fun saveToGallery(ctx: Context, file: File, mime: String, name: String, video: Boolean): Uri {
    val collection = if (video) MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
    else MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
    val values = ContentValues().apply {
        put(MediaStore.MediaColumns.DISPLAY_NAME, name)
        put(MediaStore.MediaColumns.MIME_TYPE, mime)
        put(MediaStore.MediaColumns.RELATIVE_PATH, if (video) "Movies/KSHD" else "Pictures/KSHD")
        put(MediaStore.MediaColumns.IS_PENDING, 1)
    }
    val r = ctx.contentResolver
    val uri = r.insert(collection, values) ?: error("Gagal membuat berkas di galeri")
    try {
        r.openOutputStream(uri)!!.use { out -> file.inputStream().use { it.copyTo(out) } }
        values.clear()
        values.put(MediaStore.MediaColumns.IS_PENDING, 0)
        r.update(uri, values, null, null)
    } catch (e: Throwable) {
        r.delete(uri, null, null)
        throw e
    }
    return uri
}
