package com.kshd.enhancer.ui

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.kshd.enhancer.core.*
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun VideoScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var uri by remember { mutableStateOf<Uri?>(null) }
    var vinfo by remember { mutableStateOf<VideoInfo?>(null) }
    var target by remember { mutableStateOf(ResTarget.AUTO) }
    var codec by remember { mutableStateOf(Codec.H264) }
    var q by remember { mutableStateOf(VQuality.MED) }
    var busy by remember { mutableStateOf(false) }
    var progress by remember { mutableIntStateOf(-1) }
    var stage by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    var saved by remember { mutableStateOf<Uri?>(null) }
    var result by remember { mutableStateOf<VideoResult?>(null) }
    var job by remember { mutableStateOf<Job?>(null) }

    val pick = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { u ->
        if (u != null) {
            uri = u; result = null; saved = null; error = ""; stage = ""
            vinfo = runCatching { VideoPipeline.probe(ctx, u) }.getOrElse { error = it.message ?: "Video rusak."; null }
        }
    }
    val codecs = remember { if (VideoPipeline.hevcAvailable()) Codec.values().toList() else listOf(Codec.H264) }
    val plan = remember(vinfo, target, codec, q) { vinfo?.let { VideoPipeline.plan(ctx, it, target, codec, q) } }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)) {

        Note("Mode ini adalah upscale resolusi + re-encode (Media3 Transformer), BUKAN AI Video Super Resolution. " +
            "Audio dan FPS asli dipertahankan. Biarkan layar tetap menyala selama proses.")
        Button(onClick = { pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) },
            enabled = !busy) { Text("Pilih Video") }
        vinfo?.let { Note("Sumber: ${it.dispW}×${it.dispH}, ${"%.1f".format(it.fps)} fps, ${it.durationMs / 1000}s, audio: ${if (it.hasAudio) "ya" else "tidak"}") }

        ChipRow("Resolusi (sisi panjang)", ResTarget.values().toList(), target, { it.label }) { target = it }
        ChipRow("Codec", codecs, codec, { it.label }) { codec = it }
        ChipRow("Kualitas / bitrate", VQuality.values().toList(), q, { it.label }) { q = it }

        plan?.let {
            if (it.ok) Note("Output ${it.w}×${it.h}, bitrate ±${it.bitrate / 1000} kbps, perkiraan ukuran ±${mb(it.estBytes)} MB. ${it.warning}")
            else Note(it.message, error = true)
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(enabled = !busy && uri != null && plan?.ok == true, onClick = {
                busy = true; error = ""; result = null; saved = null; progress = -1; stage = "Memproses video…"
                job = scope.launch {
                    try {
                        val r = VideoPipeline.run(ctx, uri!!, vinfo!!, plan!!, codec) { progress = it }
                        result = r
                        stage = "Selesai: ${r.w}×${r.h}, ${r.durationMs / 1000}s, audio ${if (r.hasAudio) "ada" else "tidak ada"} (terverifikasi). ${r.codecNote}"
                    } catch (e: CancellationException) {
                        stage = "Dibatalkan"
                    } catch (e: Throwable) {
                        error = "Gagal: ${e.message ?: e}"; stage = ""
                    } finally { busy = false }
                }
            }) { Text("Proses") }
            if (busy) OutlinedButton(onClick = { job?.cancel() }) { Text("Batal") }
        }

        if (busy) {
            if (progress >= 0) LinearProgressIndicator(progress = { progress / 100f }, modifier = Modifier.fillMaxWidth())
            else LinearProgressIndicator(Modifier.fillMaxWidth())
            Note(if (progress >= 0) "$progress%" else "Menunggu data progres dari encoder…")
        }
        Note(stage); Note(error, error = true)

        result?.let { r ->
            Button(onClick = {
                scope.launch {
                    try {
                        saved = withContext(Dispatchers.IO) {
                            saveToGallery(ctx, r.file, "video/mp4", "KSHD_${System.currentTimeMillis()}.mp4", true)
                        }
                    } catch (e: Throwable) { error = "Gagal menyimpan: ${e.message}" }
                }
            }) { Text("Simpan ke Galeri") }
        }
        saved?.let { u ->
            Note("Tersimpan di galeri: Movies/KSHD")
            OutlinedButton(onClick = {
                ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(u, "video/mp4").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
            }) { Text("Buka / Putar") }
        }
    }
}
