package com.kshd.enhancer

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kshd.enhancer.ui.PhotoScreen
import com.kshd.enhancer.ui.VideoScreen

private val Scheme = darkColorScheme(
    primary = Color(0xFF8B5CF6), secondary = Color(0xFF3B82F6),
    background = Color(0xFF0E0F1A), surface = Color(0xFF171826),
    surfaceVariant = Color(0xFF22243A), onBackground = Color(0xFFEDEDF7), onSurface = Color(0xFFEDEDF7)
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = Scheme) { Root() } }
    }
}

@Composable
private fun Root() {
    var tab by remember { mutableIntStateOf(0) }
    Surface(color = MaterialTheme.colorScheme.background, modifier = Modifier.fillMaxSize()) {
        Column(Modifier.statusBarsPadding().navigationBarsPadding()) {
            Text("KS HD", fontSize = 26.sp, color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.padding(start = 16.dp, top = 12.dp))
            TabRow(selectedTabIndex = tab, containerColor = MaterialTheme.colorScheme.background) {
                Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Upscale Foto") })
                Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Upscale Video") })
            }
            if (tab == 0) PhotoScreen() else VideoScreen()
        }
    }
}
