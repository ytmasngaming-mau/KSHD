# KS HD — Upscaler Foto & Video (tahap 1)

Status jujur: kode ini **belum dikompilasi/diuji** (lingkungan pembuat tidak punya Android SDK/internet).
Kemungkinan ada error build kecil saat sync pertama; perbaiki lalu uji di perangkat nyata.

## Build
1. Buka folder ini di Android Studio (Koala+ / JDK 17). Sync Gradle (wrapper akan diminta/diunduh otomatis).
2. Debug APK: `Build > Build APK(s)` atau `./gradlew assembleDebug` → `app/build/outputs/apk/debug/`.
3. Release: buat keystore (`Build > Generate Signed Bundle/APK`) lalu `assembleRelease`.
minSdk 29, tanpa izin penyimpanan & tanpa izin INTERNET.

## Model AI (WAJIB dipasang pengguna)
Model tidak disertakan (ukuran + lisensi harus Anda periksa). Syarat model `.tflite`:
float32, input tetap `[1,H,W,3]`, output `[1,H*s,W*s,3]` (s≥2), layout NHWC.
Kandidat: ESRGAN (TF Hub/Kaggle, ±50×50→×4, rentang input 0–255), atau Real-ESRGAN hasil konversi
(mis. `real-esrgan-general-x4v3`; rentang biasanya 0–1). **Verifikasi lisensi & rentang input sendiri.**
Pasang lewat tombol "Pasang model .tflite"; aplikasi memuat & memvalidasi model sebelum menerimanya.
Salah rentang input → hasil gelap/terlalu terang; ganti chip "Rentang input model".

## Yang sudah ada
- Foto: Photo Picker, tile-based SR TFLite (CPU), cek memori, target Original/2K/4K/8K/Auto,
  verifikasi dimensi hasil, JPG/PNG, slider Sebelum/Sesudah, simpan ke MediaStore, batal.
- Video: resolusi 720p–8K/Auto, H.264/HEVC, bitrate, cek encoder & penyimpanan, progres asli
  (−1 = belum tersedia, tidak dikarang), batal, verifikasi resolusi/durasi/audio, simpan ke galeri.

## Belum ada / batasan
- Video AI Super Resolution per-frame (saat ini hanya upscale resolusi biasa, diberi label jelas).
- Pemrosesan berjalan di foreground (belum WorkManager/foreground service).
- Foto: tanpa GPU delegate, alpha channel dibuang, 8K pada foto besar bisa ditolak karena memori.
- Remove BG, Face Restore, Denoiser, Compressor, History, Settings: belum dibuat.
- Belum ada unit/instrumented test.
